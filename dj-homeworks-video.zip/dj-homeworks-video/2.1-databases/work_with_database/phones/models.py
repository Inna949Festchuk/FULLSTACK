from django.db import models


class Phone(models.Model):
    # TODO: Добавьте требуемые поля
    pass
