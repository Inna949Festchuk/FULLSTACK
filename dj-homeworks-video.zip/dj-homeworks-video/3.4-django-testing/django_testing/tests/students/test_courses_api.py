def test_example():
    assert False, "Just test example"
