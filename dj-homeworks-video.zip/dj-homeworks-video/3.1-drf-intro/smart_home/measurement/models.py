from django.db import models

# TODO: опишите модели датчика (Sensor) и измерения (Measurement)
